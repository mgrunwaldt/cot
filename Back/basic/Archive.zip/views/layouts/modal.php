<?php

Modal::begin([
    'header' => '<h4>Destination</h4>',
    'id'     => 'model',
    'size'   => 'model-lg',
]);

echo "<div id='modelContent'></div>";

Modal::end();

?>