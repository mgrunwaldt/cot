<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=cot_db',
    'username' => 'cot_user',
    'password' => 'Usuario',
    'charset' => 'utf8',

];
