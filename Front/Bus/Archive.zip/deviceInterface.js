var counter = 0;

function getLatitudLongitude(){
    var latitud = -34.901112;
    var longitud = -56.164532;
    var ret = [];
    ret.latitud = latitud;
    ret.longitud = longitud;
    return ret;
}